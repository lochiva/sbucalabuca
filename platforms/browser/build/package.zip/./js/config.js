var firebaseConfig = {
    apiKey: "AIzaSyBAiA4VQdynEdIgKBJJOnCY3Mz6nGhjg74",
    authDomain: "sbuca-6248d.firebaseapp.com",
    databaseURL: "https://sbuca-6248d.firebaseio.com",
    storageBucket: "gs://sbuca-6248d.appspot.com",
    messagingSenderId: "851026370852"
};